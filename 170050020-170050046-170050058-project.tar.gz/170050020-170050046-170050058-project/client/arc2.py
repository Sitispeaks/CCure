from Crypto.Cipher import ARC2
from Crypto import Random

def encrypt(file_name):
	def pad(s):
		return s + b"\0" * (ARC2.block_size - len(s) % ARC2.block_size)

	key = b'[EX\xc8\xd5\xbfI{\xa2$\x05(\xd5\x18\xbf\xc0\x85)\x10nc\x94\x02)j\xdf\xcb\xc4\x94\x9d(\x9e'

	key1 = 'this is key 1 to'
	key2 = 'this is key 2 to'
	key3 = 'this is key 3 to'

	iv = Random.new().read(ARC2.block_size)

	cipher_encrypt1 = ARC2.new(key1, ARC2.MODE_CFB, iv)

	cipher_encrypt2 = ARC2.new(key2, ARC2.MODE_CFB, iv)

	cipher_encrypt3 = ARC2.new(key3, ARC2.MODE_CFB, iv)

	#file_name = str(input("Enter name of file to encrypt: "))

	with open(file_name, 'rb') as fo:
            plaintext = fo.read()

	plaintext = pad(plaintext)

	enc = cipher_encrypt1.encrypt(plaintext)

	with open(file_name + ".enc", 'wb') as fo:
			fo.write(iv+enc)

	with open(file_name + ".enc", 'rb') as fo:
			encrypted_text = fo.read()

	iv1 = encrypted_text[:ARC2.block_size]

	cipher_decrypt1 = ARC2.new(key1, ARC2.MODE_CFB, iv1)

	cipher_decrypt2 = ARC2.new(key2, ARC2.MODE_CFB, iv1)

	cipher_decrypt3 = ARC2.new(key3, ARC2.MODE_CFB, iv1)

	dec = cipher_decrypt1.decrypt(encrypted_text[ARC2.block_size:])
	dec_file = dec.rstrip(b"\0")

	with open(file_name+"1", 'wb') as fo:
			fo.write(dec_file)

