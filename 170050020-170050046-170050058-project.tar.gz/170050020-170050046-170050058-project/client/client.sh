var="sudo apt-get update"
eval $var

var="sudo apt-get install python"
eval $var

var="sudo apt-get install python3"
eval $var

var="sudo apt-get install python3 python3-pip"
eval $var

var="sudo apt-get install python-mechanize"
eval $var

var="sudo apt-get install python-crypto"
eval $var

var="sudo apt-get install notify-osd"
eval $var

var="sudo mv spc /usr/bin/spc"
eval $var

var="crontab dummy"
eval $var

var="mkdir /usr/local/man/man8"
eval $var

var="sudo cp spc.8 /usr/local/man/man8"
eval $var
