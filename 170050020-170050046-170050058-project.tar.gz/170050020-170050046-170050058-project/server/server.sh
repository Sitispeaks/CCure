var="sudo apt-get update"
eval $var

var="sudo apt-get install python"
eval $var

var="sudo apt-get install python3"
eval $var

var="sudo apt-get install python3 python3-pip"
eval $var

var="pip3 install django"
eval $var

var="pip3 install django-db-file-storage"
eval $var

var="cd SPC/"
eval $var

var="python3 manage.py makemigrations"
eval $var

var="python3 manage.py migrate"
eval $var

var="python3 manage.py runserver"
eval $var